<?php
$EM_CONF[$_EXTKEY] = array(
    'title'            => '[DE] Gestionnaire de formulaires génériques - Exemple (Fluid)',
    'description'      => 'Exemple de formulaire basé sur EXT:de_forms',
    'category'         => 'backend',
    'author'           => 'Romain Canon',
    'author_company'   => 'Direct Energie',
    'author_email'     => 'romain.canon.ext@direct-energie.com',
    'dependencies'     => '',
    'clearCacheOnLoad' => 1,
    'version'          => '1.0.1',
    'constraints'      => array(
        'depends' => array(
            'formz' => '0.0.0-0.99.99'
        )
    )
);
