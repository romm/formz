<?php
/*
 * 2015
 * Romain CANON <romain.canon.ext@direct-energie.com>
 */

namespace Romm\FormzTemplate\Domain\Model;

use Romm\Formz\Domain\Model\AbstractForm;

/**
 * Example form
 */
class ExampleForm extends AbstractForm
{

    /**
     * Email.
     *
     * @var string
     */
    protected $email;

    /**
     * Name.
     *
     * @var string
     */
    protected $name;

    /**
     * First name.
     *
     * @var string
     */
    protected $firstName;

    /**
     * Has a certificate?
     *
     * @var bool
     */
    protected $hasCertificate;

    /**
     * Certificate name.
     *
     * @var string
     */
    protected $certificateName;

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }

    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    }

    public function getHasCertificate()
    {
        return $this->hasCertificate;
    }

    public function setHasCertificate($hasCertificate)
    {
        $this->hasCertificate = $hasCertificate;
    }

    public function getCertificateName()
    {
        return $this->certificateName;
    }

    public function setCertificateName($certificateName)
    {
        $this->certificateName = $certificateName;
    }
}