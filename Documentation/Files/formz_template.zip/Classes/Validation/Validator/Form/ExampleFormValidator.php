<?php
/*
 * 2015
 * Romain CANON <romain.canon.ext@direct-energie.com>
 */

namespace Romm\FormzTemplate\Validation\Validator\Form;

use Romm\Formz\Validation\Validator\Form\AbstractFormValidator;
use Romm\FormzTemplate\Domain\Model\ExampleForm;

class ExampleFormValidator extends AbstractFormValidator
{

    /**
     * @var ExampleForm
     */
    protected $form;

    /**
     * @inheritdoc
     */
    protected function processForm()
    {
        // Activate "Certificate Name" validation if the person has a certificate.
        if ($this->form->getHasCertificate()) {
            $this->activateField('certificateName');
        }
    }

    /**
     * @inheritdoc
     */
    protected function afterValidation()
    {
    }
}