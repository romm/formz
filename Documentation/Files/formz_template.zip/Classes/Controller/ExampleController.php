<?php
/*
 * 2015
 * Romain CANON <romain.canon.ext@direct-energie.com>
 */

namespace Romm\FormzTemplate\Controller;

use Romm\Formz\Controller\AbstractController;
use Romm\FormzTemplate\Domain\Model\ExampleForm;

class ExampleController extends AbstractController
{

    /**
     * Does some stuff...
     *
     * @inheritdoc
     */
    public function initializeAction()
    {
        // Calling the parent function not to break functionality (!).
        parent::initializeAction();
    }

    /**
     * Show an example form.
     */
    public function showFormAction()
    {
        /** @var ExampleForm $submittedForm */
        $submittedForm = self::getFormWithErrors(ExampleForm::class);

        $this->view->assign('form', $submittedForm);
    }

    /**
     * @see \Romm\Formz\Controller\AbstractController::redirectIfRequiredArgumentIsMissing()
     */
    public function initializeSubmitFormAction()
    {
        $this->redirectIfRequiredArgumentIsMissing('showForm');
    }

    /**
     * Action called when the Example form is submitted.
     *
     * @param    ExampleForm $exForm
     * @validate $exForm Romm.FormzTemplate:Form\ExampleFormValidator
     */
    public function submitFormAction(ExampleForm $exForm)
    {
        $this->view->assign('form', $exForm);
    }
}